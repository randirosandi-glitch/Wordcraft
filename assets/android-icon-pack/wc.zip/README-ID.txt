PAKET IKON ANDROID — WORDCRAFT

SUDUT IKON:
- Area di luar bentuk rounded-square adalah TRANSPARAN (alpha 0).
- Tidak ada kotak hitam/putih atau warna lain di belakang sudut membulat.
- Warna biru hanya berada di dalam bidang ikon.
- Adaptive icon menggunakan warna biru yang sama sebagai background Android.

Isi:
- play-store-icon-512.png: ikon 512 x 512
- preview/icon-master-1024.png: master PNG 1024 x 1024
- mipmap-mdpi sampai mipmap-xxxhdpi: launcher PNG density Android
- mipmap-anydpi-v26: adaptive icon Android 8+
- drawable/ic_launcher_monochrome.png: glyph themed icon
- values/colors.xml: warna background adaptive icon

Pemasangan:
1. Cadangkan app/src/main/res/ proyek.
2. Salin isi folder android/app/src/main/res/ ke app/src/main/res/.
3. Pastikan AndroidManifest.xml memuat:
   android:icon="@mipmap/ic_launcher"
   android:roundIcon="@mipmap/ic_launcher_round"
4. Build ulang APK.

Paket ini berisi resource ikon, bukan APK yang sudah dimodifikasi.
